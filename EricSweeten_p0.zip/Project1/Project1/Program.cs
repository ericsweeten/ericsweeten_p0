﻿using System;
using System.Data.SqlClient;
using System.Text;

namespace Project0
{
    internal class Program
    {
        private static SqlConnection con = new SqlConnection("server=DESKTOP-EMQBT1J\\ERIC_INSTANCE;database=bankingDB;Integrated Security = True;MultipleActiveResultSets=true");
        private static class Constants
        {
            public const string stringTransactionComplete = "Transaction complete.";
            public const string stringInsufficientFunds = "Insufficient funds.";
            public const string stringAmountMustBePositive = "Amount must be positive.";
            public const string stringLoggedInAs = "Logged in as: ";
            public const string stringAdmin = "admin";
            public const string stringBanker = "banker";
            public const string stringCustomer = "customer";
            public const string stringTransferAmount = "Enter transfer amount: $";
            public const string stringAmount = "Amount: $";
            public const string stringCustomerDoesntExist = "Customer account # does not exist.";
            public const string stringCustomerAccountHasBeen = "Customer account has been ";
            public const string stringTransferToSameAccountError = "A transfer cannot be made from one account to the same account.";
        }
        static void Main(string[] args)
        {
            var choice = 0;
            while (choice != 3)
            {
                DisplayBankName();
                Console.WriteLine(FillBlocks(15));
                Console.Write(FillBlocks(1));
                DisplayMenuItem(1, "Admin", 4, 1);
                DisplayMenuItem(2, "Customer", 1, 1);
                DisplayMenuItem(3, "Exit", 5, 15);
                choice = GetSelectionPrompt();
                switch (choice)
                {
                    case 1:
                        MenuAdmin();
                        break;
                    case 2:
                        MenuCustomer();
                        break;
                }
            }
        }
        /*
         * Admin menu
         */
        private static void MenuAdmin()
        {
            var success = false;
            var username = String.Empty;
            for (int i = 2; i > -1; i--)
            {
                username = GetUsernameOrPassword(false, true);  //admin, username
                if (username == String.Empty) break;
                String password = GetUsernameOrPassword(false, false); //admin, password
                if (password == String.Empty) break;
                var valid = ValidateCredentials(username, password);
                if (valid)
                {
                    success = true;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid credentials. " + i + " attempt" + (i > 1 ? "s" : "") + " left.");
                }
            }
            if (success && username == Constants.stringAdmin)
            {
                #region successful admin login
                var choice = 0;
                Customer cust;
                while (choice != 8)
                {
                    int amount;
                    DisplayBankName();
                    DisplayLoggedInAs(Constants.stringAdmin);
                    Console.WriteLine(FillBlocks(41));
                    Console.Write(FillBlocks(1));
                    DisplayMenuItem(1, "Create new account", 17, 1);
                    DisplayMenuItem(2, "View all account details in a list", 1, 1);
                    DisplayMenuItem(3, "Perform customer withdrawal", 8, 1);
                    DisplayMenuItem(4, "Perform customer deposit", 11, 1);
                    DisplayMenuItem(5, "Transfer funds", 21, 1);
                    DisplayMenuItem(6, "Disable an account", 17, 1);
                    DisplayMenuItem(7, "Enable an account", 18, 1);
                    DisplayMenuItem(8, "Exit", 31, 41);
                    choice = GetSelectionPrompt();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    switch (choice)
                    {
                        #region create new account
                        case 1:
                            string name;
                            var balance = 0;
                            while (true)
                            {
                                var invalid = false;
                                Console.Write("Enter username of new customer: ");
                                Console.ForegroundColor = ConsoleColor.White;
                                name = Console.ReadLine();
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                var cmd = new SqlCommand("select count(*) from tbl_login where username = @username", GetSQLCon());
                                cmd.Parameters.AddWithValue("@username", name);
                                GetSQLCon().Open();
                                if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                                {
                                    invalid = true;
                                    Console.WriteLine("Username already taken. Please try another.");
                                }
                                else if (name.Length > 10)
                                {
                                    invalid = true;
                                    Console.WriteLine("Username can't be more than 10 characters.");
                                }
                                GetSQLCon().Close();
                                if (!invalid) break;
                            }
                            var accountNum = Customer.GetNewAccountNumber();
                            Console.WriteLine("Customer has been assigned account # " + accountNum);
                            var balanceError = true;
                            while (balanceError)
                            {
                                var invalid = false;
                                Console.Write("Enter customer's starting balance: ");
                                Console.ForegroundColor = ConsoleColor.White;
                                var openingBalance = Console.ReadLine();
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                try
                                {
                                    balance = Convert.ToInt32(openingBalance);
                                    if (balance >= 0) balanceError = false;
                                }
                                catch (FormatException)
                                {
                                    invalid = true;
                                }
                                catch (OverflowException)
                                {
                                    invalid = true;
                                }
                                if (invalid)
                                {
                                    Console.WriteLine("Not a valid entry. Please try again.");
                                    Pause();
                                }
                            }
                            Console.WriteLine("Customer's starting password is the word 'password' (without the apostrophes). Please advice them to change it immediately.");
                            var customer = new Customer(name, accountNum, balance);
                            Customer.AddCustomer(customer);
                            break;
                        #endregion
                        #region view all account details in a list
                        case 2:
                            using (var command = GetSQLCon().CreateCommand())
                            {
                                command.CommandText = "select username,balance,accountNumber from tbl_custInfo";
                                GetSQLCon().Open();
                                using (var reader = command.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        var custUsername = Convert.ToString(reader["username"]);
                                        var custBalance = Convert.ToInt32(reader["balance"]);
                                        var custAccountNumber = Convert.ToString(reader["accountNumber"]);
                                        var cmd = new SqlCommand("select accountStatus from tbl_login where username = @username", con);
                                        cmd.Parameters.AddWithValue("@username", custUsername);
                                        var reader2 = cmd.ExecuteReader();
                                        reader2.Read();
                                        var custEnabled = Convert.ToBoolean(reader2["accountStatus"]);
                                        reader2.Close();
                                        Console.ForegroundColor = ConsoleColor.Magenta;
                                        Console.WriteLine("\nAccount #: " + custAccountNumber);
                                        Console.WriteLine("Account username: " + custUsername);
                                        Console.WriteLine("Account balance: $" + custBalance);
                                        Console.WriteLine("Account active: " + custEnabled);
                                        Customer.GetCustomer(custAccountNumber).DisplayLast10Transactions();
                                        DisplayDelimeter();
                                    }
                                    reader.Close();
                                }
                                GetSQLCon().Close();
                            }
                            break;
                        #endregion
                        #region perform customer withdrawal
                        case 3:
                            GetSQLCon().Open();
                            accountNum = RetrieveAccountNumber();
                            if (accountNum != "-1")
                            {
                                amount = GetParsedNumber(Constants.stringAmount);
                                if (amount > 0)
                                {

                                    cust = Customer.GetCustomer(accountNum);

                                    var cmd = new SqlCommand("select balance from tbl_custInfo where accountNumber = @accountNum", con);
                                    cmd.Parameters.AddWithValue("@accountNum", accountNum);
                                    var reader = cmd.ExecuteReader();
                                    reader.Read();
                                    var bal = Convert.ToInt32(reader["balance"]);
                                    reader.Close();

                                    if (amount <= cust.custBalance)
                                    {
                                        cust.custBalance -= amount;
                                        cmd = new SqlCommand("update tbl_custInfo set balance = @balance where accountNumber = @accountNum", con);
                                        cmd.Parameters.AddWithValue("@balance", cust.custBalance);
                                        cmd.Parameters.AddWithValue("@accountNum", accountNum);
                                        cmd.ExecuteNonQuery();
                                        cust.AddTransaction(amount, Constants.stringBanker, "Withdrawal");
                                        Console.WriteLine(Constants.stringTransactionComplete);
                                        Customer.UpdateCustomerData(cust, Customer.CustomerProperty.BALANCE);
                                    }
                                    else if (amount < 0)
                                    {
                                        Console.WriteLine(Constants.stringAmountMustBePositive);
                                    }
                                    else
                                    {
                                        Console.WriteLine(Constants.stringInsufficientFunds);
                                    }
                                }
                            }
                            GetSQLCon().Close();
                            break;
                        #endregion
                        #region perform customer deposit
                        case 4:
                            GetSQLCon().Open();
                            accountNum = RetrieveAccountNumber();
                            if (accountNum != "-1")
                            {
                                amount = GetParsedNumber(Constants.stringAmount);
                                if (amount > 0)
                                {
                                    cust = Customer.GetCustomer(accountNum);
                                    if (amount > 0)
                                    {
                                        cust.custBalance += amount;
                                        var cmd = new SqlCommand("update tbl_custInfo set balance = @balance where accountNumber = @accountNum", con);
                                        cmd.Parameters.AddWithValue("@balance", cust.custBalance);
                                        cmd.Parameters.AddWithValue("@accountNum", accountNum);
                                        cmd.ExecuteNonQuery();
                                        cust.AddTransaction(amount, Constants.stringBanker, "Deposit");
                                        Console.WriteLine(Constants.stringTransactionComplete);
                                        Customer.UpdateCustomerData(cust, Customer.CustomerProperty.BALANCE);
                                    }
                                    else
                                    {
                                        Console.WriteLine(Constants.stringAmountMustBePositive);
                                    }
                                }
                            }
                            GetSQLCon().Close();
                            break;
                        #endregion
                        #region transfer funds
                        case 5:
                            string numAccountFrom;
                            string numAccountTo;
                            amount = GetParsedNumber(Constants.stringTransferAmount);
                            if (amount > 0)
                            {
                                Console.WriteLine("From:");
                                GetSQLCon().Open();
                                numAccountFrom = RetrieveAccountNumber();
                                if (numAccountFrom != "-1")
                                {
                                    Console.WriteLine("To:");
                                    numAccountTo = RetrieveAccountNumber();
                                    if (numAccountTo != "-1")
                                    {
                                        if (numAccountFrom == numAccountTo)
                                        {
                                            Console.WriteLine(Constants.stringTransferToSameAccountError);
                                        }
                                        else
                                        {
                                            var custFrom = Customer.GetCustomer(numAccountFrom);
                                            var custTo = Customer.GetCustomer(numAccountTo);
                                            if (amount > custFrom.custBalance)
                                            {
                                                Console.WriteLine(Constants.stringInsufficientFunds);
                                            }
                                            else
                                            {
                                                custTo.custBalance += amount;
                                                custFrom.custBalance -= amount;
                                                custTo.AddTransaction(amount, Constants.stringBanker, "Transfer from " + custFrom.custAccountNumber);
                                                custFrom.AddTransaction(amount, Constants.stringBanker, "Transfer to " + custTo.custAccountNumber);
                                                Customer.UpdateCustomerData(custFrom, Customer.CustomerProperty.BALANCE);
                                                Customer.UpdateCustomerData(custTo, Customer.CustomerProperty.BALANCE);
                                                Console.WriteLine(Constants.stringTransactionComplete);
                                            }
                                        }
                                    }
                                }
                            }
                            GetSQLCon().Close();
                            break;
                        #endregion
                        #region disable an account
                        case 6:
                            Console.WriteLine("Enter account # to disable.");
                            GetSQLCon().Open();
                            accountNum = RetrieveAccountNumber();
                            if (accountNum != "-1")
                            {
                                cust = Customer.GetCustomer(accountNum);
                                cust.custAccountStatus = false;
                                cust.custLoginAttempts = 3;
                                Customer.UpdateCustomerData(cust, Customer.CustomerProperty.STATUS);
                                Console.WriteLine(Constants.stringCustomerAccountHasBeen + "disabled.");
                            }
                            GetSQLCon().Close();
                            break;
                        #endregion
                        #region enable an account
                        case 7:
                            Console.WriteLine("Enter account # to enable.");
                            GetSQLCon().Open();
                            accountNum = RetrieveAccountNumber();
                            if (accountNum != "-1")
                            {
                                cust = Customer.GetCustomer(accountNum);
                                cust.custAccountStatus = true;
                                cust.custLoginAttempts = 0;
                                Customer.UpdateCustomerData(cust, Customer.CustomerProperty.STATUS);
                                Console.WriteLine(Constants.stringCustomerAccountHasBeen + "enabled.");
                            }
                            GetSQLCon().Close();
                            break;
                        #endregion
                    }
                    if (choice > 0 && choice < 9) Pause();
                }
                #endregion
            }
        }
        /*
         * Customer menu
         */
        private static void MenuCustomer()
        {
            var custValid = false;
            var username = GetUsernameOrPassword(true, true);   //customer, username
            if (username == String.Empty) return;
            var password = GetUsernameOrPassword(true, false);  //customer, password
            if (password == String.Empty) return;
            custValid = ValidateCredentials(username, password);
            GetSQLCon().Open();
            if (custValid && username != Constants.stringAdmin)
            {
                #region successful customer login
                var cmd = new SqlCommand("select accountStatus from tbl_login where username = @username", con);
                cmd.Parameters.AddWithValue("@username", username);
                var reader = cmd.ExecuteReader();
                reader.Read();
                var isActive = Convert.ToBoolean(reader["accountStatus"]);
                reader.Close();

                //resets the counter of failed login attempts when the user gets the login right
                var command = GetSQLCon().CreateCommand();
                command.CommandText = "select accountNumber from tbl_custInfo where username = @username";
                command.Parameters.AddWithValue("@username", username);
                reader = command.ExecuteReader();
                reader.Read();
                var customer = Customer.GetCustomer(Convert.ToString(reader["accountNumber"]));
                customer.custLoginAttempts = 0;
                Customer.UpdateCustomerData(customer, Customer.CustomerProperty.ATTEMPTS);
                reader.Close();

                if (!isActive)
                {
                    Console.WriteLine("This account has been locked. Please contact the administrator.");
                    Pause();
                }
                else
                {
                    var choice = 1;
                    while (choice != 7)
                    {
                        var amount = 0;
                        DisplayBankName();
                        DisplayLoggedInAs(customer.custUsername);
                        Console.WriteLine(FillBlocks(32));
                        Console.Write(FillBlocks(1));
                        DisplayMenuItem(1, "Check balance", 13, 1);
                        DisplayMenuItem(2, "Withdraw", 18, 1);
                        DisplayMenuItem(3, "Deposit", 19, 1);
                        DisplayMenuItem(4, "Transfer", 18, 1);
                        DisplayMenuItem(5, "View last 10 transactions", 1, 1);
                        DisplayMenuItem(6, "Change password", 11, 1);
                        DisplayMenuItem(7, "Exit", 22, 32);
                        choice = GetSelectionPrompt();
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        switch (choice)
                        {
                            #region check balance
                            case 1:
                                Console.WriteLine("Current balance: $" + customer.custBalance);
                                break;
                            #endregion
                            #region withdraw
                            case 2:
                                var success = false;
                                amount = GetParsedNumber(Constants.stringAmount);
                                if (amount > 0)
                                {
                                    if (amount <= customer.custBalance)
                                    {
                                        customer.custBalance -= amount;
                                        cmd = new SqlCommand("update tbl_custInfo set balance = @balance where accountNumber = @accountNum", con);
                                        cmd.Parameters.AddWithValue("@balance", customer.custBalance);
                                        cmd.Parameters.AddWithValue("@accountNum", customer.custAccountNumber);
                                        cmd.ExecuteNonQuery();
                                        customer.AddTransaction(amount, Constants.stringCustomer, "Withdrawl");
                                        Customer.UpdateCustomerData(customer, Customer.CustomerProperty.BALANCE);
                                        success = true;
                                    }
                                    else
                                    {
                                        Console.Write(Constants.stringInsufficientFunds);
                                    }
                                    if (success) Console.WriteLine(Constants.stringTransactionComplete);
                                }
                                break;
                            #endregion
                            #region deposit
                            case 3:
                                amount = GetParsedNumber(Constants.stringAmount);
                                if (amount > 0)
                                {
                                    customer.custBalance += amount;
                                    cmd = new SqlCommand("update tbl_custInfo set balance = @balance where accountNumber = @accountNum", con);
                                    cmd.Parameters.AddWithValue("@balance", customer.custBalance);
                                    cmd.Parameters.AddWithValue("@accountNum", customer.custAccountNumber);
                                    cmd.ExecuteNonQuery();
                                    customer.AddTransaction(amount, Constants.stringCustomer, "Deposit");
                                    Console.WriteLine(Constants.stringTransactionComplete);
                                    Customer.UpdateCustomerData(customer, Customer.CustomerProperty.BALANCE);
                                }
                                break;
                            #endregion
                            #region transfer
                            case 4:
                                amount = GetParsedNumber(Constants.stringTransferAmount);
                                if (amount > 0)
                                {
                                    var s = RetrieveAccountNumber();
                                    if (s != "-1")
                                    {
                                        if (s == customer.custAccountNumber)
                                        {
                                            Console.WriteLine(Constants.stringTransferToSameAccountError);
                                            break;
                                        }
                                        else
                                        {
                                            if (amount <= customer.custBalance)
                                            {
                                                var custTo = Customer.GetCustomer(s);
                                                customer.custBalance -= amount;
                                                custTo.custBalance += amount;
                                                customer.AddTransaction(amount, Constants.stringCustomer, "Transfer to " + custTo.custAccountNumber);
                                                custTo.AddTransaction(amount, "a fellow customer", "Transfer from " + customer.custAccountNumber);
                                                Customer.UpdateCustomerData(customer, Customer.CustomerProperty.BALANCE);
                                                Customer.UpdateCustomerData(custTo, Customer.CustomerProperty.BALANCE);
                                                Console.WriteLine(Constants.stringTransactionComplete);
                                            }
                                            else
                                            {
                                                Console.WriteLine(Constants.stringInsufficientFunds);
                                            }
                                        }
                                    }
                                }
                                break;
                            #endregion
                            #region view last 10 transactions
                            case 5:
                                customer.DisplayLast10Transactions();
                                break;
                            #endregion
                            #region change password
                            case 6:
                                Console.Write("Enter current password: ");
                                Console.ForegroundColor = ConsoleColor.White;
                                var pw = Console.ReadLine();
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                if (pw == customer.custPassword)
                                {
                                    Console.Write("Enter new password: ");
                                    Console.ForegroundColor = ConsoleColor.White;
                                    var pw1 = Console.ReadLine();
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.Write("Re-enter new password to confirm: ");
                                    Console.ForegroundColor = ConsoleColor.White;
                                    var pw2 = Console.ReadLine();
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    if (pw1 == pw2)
                                    {
                                        customer.custPassword = pw1;
                                        Console.WriteLine("Password successfuly changed.");
                                        Customer.UpdateCustomerData(customer, Customer.CustomerProperty.PWORD);
                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Passwords do not match.");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Invalid password.");
                                    break;
                                }
                                break;
                            #endregion
                        }
                        if (choice > 0 && choice < 8) Pause();
                    }
                }
                #endregion
            }
            else
            {
                #region unsuccessful customer login
                var remaining = 0;
                var noSuchUser = false;
                try
                {
                    if (username == Constants.stringAdmin)
                    {
                        noSuchUser = true;
                    }
                    else
                    {
                        var attempts = 0;
                        var cmd = GetSQLCon().CreateCommand();
                        cmd.CommandText = "select attempts from tbl_login where username = @username";
                        cmd.Parameters.AddWithValue("@username", username);
                        using (var reader = cmd.ExecuteReader())
                        {
                            reader.Read();
                            attempts = Convert.ToInt32(reader["attempts"]); 
                            reader.Close();
                        }
                        attempts++;  //it still records how many attempts are made at accessing the account
                        if (attempts == 4) attempts = 3;
                        cmd = new SqlCommand("update tbl_login set attempts = @attempts where username = @username", con);
                        cmd.Parameters.AddWithValue("@attempts", attempts);
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.ExecuteNonQuery();
                        remaining = 3 - attempts;
                    }
                }
                catch (InvalidOperationException)  //no such user
                {
                    noSuchUser = true;
                }
                finally
                {
                    Console.WriteLine("Invalid credentials. " + (!noSuchUser ? remaining + " attempt" + (remaining > 1 ? "s" : "") + " left." : ""));
                    if (remaining == 0)
                    {
                        var cmd = new SqlCommand("update tbl_login set accountStatus = 0 where username = @username", con);
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("This account has been locked because of repeat failed login attempts. Please contact the administrator to have access restored.");  //this message shows when they try to login as admin
                    }
                }
                Pause();
                #endregion
            }
            GetSQLCon().Close();
        }
        /*
         * Prompts the user to enter in an account number, then returns one if it's valid, otherwise returns "-1"
         */
        private static string RetrieveAccountNumber()
        {
            var validAccount = false;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Enter account number: ");
            Console.ForegroundColor = ConsoleColor.White;
            var account = Console.ReadLine().Trim();
            Console.ForegroundColor = ConsoleColor.Cyan;
            var cmd = new SqlCommand("select count(*) from tbl_custInfo where accountNumber = @accountNum", Program.GetSQLCon());
            cmd.Parameters.AddWithValue("@accountNum", account);
            var count = 0;
            try
            {
                count = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (InvalidOperationException)  //no such account in the database
            {
            }
            if (count == 1)
            {
                validAccount = true;
            }
            else
            {
                Console.WriteLine("Invalid account number.");
            }
            return validAccount ? account : "-1";
        }
        /*
         *  Presents a prompt asking the user for a selection, attempts to parse it to an int, and returns the choice the user made (default = 0)
         */
        private static int GetSelectionPrompt()
        {
            var choice = 0;
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\nSelection: ");
            Console.ForegroundColor = ConsoleColor.White;
            try
            {
                choice = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
            }
            catch (OverflowException)
            {
            }
            return choice;
        }
        /*
         * Helper method to present the customer for one of four prompts, received their response, and returns it in a string
         * There are four potential combos based on two bool parameters:
         * Enter customer username:
         * Enter customer password:
         * Enter admin username:
         * Enter admin password:
         */
        private static String GetUsernameOrPassword(bool isCustomer, bool isUsername)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Hit enter to cancel.");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Enter " + (isCustomer ? Constants.stringCustomer : Constants.stringAdmin) + " " + (isUsername ? "username" : "password") + ": ");
            Console.ForegroundColor = ConsoleColor.White;
            var usernameOrPw = Console.ReadLine();
            return usernameOrPw;
        }
        /*
         * Prompts the user with the passed-in message and attempts to parse it to an integer.  If not a valid integer, returns 0.
         */
        private static int GetParsedNumber(string message)
        {
            var num = 0;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(message);
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                try
                {
                    num = Convert.ToInt32(Console.ReadLine());
                    if (num >= 0)
                    {
                        break;
                    }
                }
                catch (FormatException)
                {
                }
                catch (OverflowException)
                {
                }
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Invalid number. Please re-enter. 0 to cancel.");
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            return num;
        }
        /*
         * Attempts to find a username and matching password in the tbl_login database.  If found, returns true; otherwise, returns false.
         */
        public static bool ValidateCredentials(string username, string password)
        {
            var cmd = new SqlCommand("select count(*) from tbl_login where username = @username and pword = @pword", Program.GetSQLCon());
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@pword", password);
            var count = 0;
            try
            {
                GetSQLCon().Open();
                count = (int)cmd.ExecuteScalar();
                GetSQLCon().Close();

            }
            catch (SqlException)
            {
                return false;
            }
            var valid = false;
            if (count == 1) valid = true;
            return valid;
        }
        /*
         * Helper method to pause while prompting the user to hit enter to continue
         */
        public static void Pause()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("\nPress the enter key to continue...");
            Console.ReadLine();
        }
        /*
         * Displays the bank name header, used for all three menus
         * Grabbed from https://ascii.today/ (Wavy font by Brian Krog)
         * 
         */
        private static void DisplayBankName()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.BackgroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine(" __                            _        \n" + 
                              " )_)  _   _  (_ o  _   _      /_) _   _ \n" +
                              "/__) (_(  )) )\\ ( ) ) (_(    / / )_) )_)\n" +
                              "                       _)        (   (  ");
            Console.BackgroundColor = ConsoleColor.Black;
            DisplayDelimeter();
        }
        /*
         * Displays a delimeter (separator) for aesthetic reasons
         */
        private static void DisplayDelimeter()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n");
        }
        /*
         * Displays who is logged in
         */
        private static void DisplayLoggedInAs(string user)
        {
            Console.Write(Constants.stringLoggedInAs);
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(user + "\n");
        }
        /*
         * Displays the menu option number and associated explanation
         */
        private static void DisplayMenuItem(int index, string option, int spacing, int last)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write(index + ") ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(option);
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < spacing; i++)
            {
                s.Append(" ");
            }
            Console.Write(Convert.ToString(s));
            Console.Write(FillBlocks(1));
            Console.WriteLine();
            Console.Write(FillBlocks(last));
        }
        /*
         * Builds a string of a shaded background unicode character, the size of which is determined by the parameter
         */
        private static string FillBlocks(int amount)
        {
            var s = new StringBuilder();
            for (int i = 0; i < amount; i++)
            {
                s.Append("\u2592");
            }
            s.Append(" ");
            Console.ForegroundColor = ConsoleColor.Blue;
            return Convert.ToString(s);
        }
        /*
         * The SQL connection is instantiated at program execution in a private static field and accessed via this public static getter
         */
        public static SqlConnection GetSQLCon()
        {
            return con;
        }
    }
}