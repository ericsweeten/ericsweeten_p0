﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

namespace Project0
{
    internal class Customer
    {
        public string custUsername { get; set; }
        public string custPassword { get; set; }
        public int custBalance { get; set; }
        public string custAccountNumber { get; set; }
        public int custLoginAttempts { get; set; }
        public bool custAccountStatus { get; set; }
        public enum CustomerProperty
        {
            BALANCE,
            PWORD,
            STATUS,
            ATTEMPTS
        }
        /*
         * Default Customer constructor to create new customer objects without yet knowing the information
         */
        public Customer()
        {
        }
        /*
         * Creates a customer based off known information about the customer
         */
        public Customer(string username, string accountNumber, int balance)
        {
            custUsername = username;
            custAccountNumber = accountNumber;
            custBalance = balance;
            custPassword = "password";
            custAccountStatus = true;
        }
        /*
         * Adds a transaction to the tbl_transactions database
         */
        public void AddTransaction(int amount, string by, string notes)
        {
            var cmd = new SqlCommand("insert into tbl_transactions(accountNumber, dateAndTime, amount, by_, notes) values (@accountNum, GETDATE(), @amount, @by, @notes);", Program.GetSQLCon());
            cmd.Parameters.AddWithValue("@accountNum", custAccountNumber);
            cmd.Parameters.AddWithValue("@amount", amount);
            cmd.Parameters.AddWithValue("@by", by);
            cmd.Parameters.AddWithValue("@notes", notes);
            cmd.ExecuteNonQuery();
        }
        /*
         * Retrieves the last 10 transactions all in a single string, build using a StringBuilder
         */
        public void DisplayLast10Transactions()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            var s = new StringBuilder("\nLast 10 transactions:\n\n");
            //var custTransactionHistory = new List<string>();
            var cmd = new SqlCommand("select count(*) from tbl_transactions where accountNumber = @accountNum", Program.GetSQLCon());
            cmd.Parameters.AddWithValue("@accountNum", custAccountNumber);
            Console.ForegroundColor = ConsoleColor.Cyan;
            var count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count == 0)
            {
                s.Append("No transactions yet.\n");
            }
            else
            {
                using (var command = Program.GetSQLCon().CreateCommand())
                {
                    command.CommandText = "select top 10 tranNo,dateAndTime,amount,by_,notes from tbl_transactions where accountNumber = @accountNum order by tranNo desc";
                    command.Parameters.AddWithValue("@accountNum", custAccountNumber);
                    using (var reader = command.ExecuteReader())
                    {
                        //8293921094
                        while (reader.Read())
                        {
                            s.Append("Transaction #");
                            s.Append(reader["tranNo"]);
                            s.Append(": ");
                            s.Append(reader["notes"]);
                            s.Append(" by ");
                            s.Append(reader["by_"]);
                            s.Append(" on ");
                            s.Append(reader["dateAndTime"]);
                            s.Append(" in the amount of $");
                            s.Append(reader["amount"]);
                            s.Append("\n");                            
                        }
                        reader.Close();
                    }
                }
            }
            Console.WriteLine(Convert.ToString(s));
        }
        /*
         * Generates and returns an unused 10-digit account # that doesn't start with 0
         */
        public static string GetNewAccountNumber()
        {
            var newlyGeneratedAccountNum = string.Empty;
            Program.GetSQLCon().Open();
            while (true)
            {
                var random = new Random();
                for (int i = 0; i < 10; i++)
                {
                    var toAdd = random.Next(10);
                    if (i == 0 && toAdd == 0)  //ensures account # doesn't start with '0'
                    {
                        i--;
                        newlyGeneratedAccountNum = string.Empty;
                    }
                    else
                    {
                        newlyGeneratedAccountNum = String.Concat(newlyGeneratedAccountNum, toAdd);
                    }
                }
                var cmd = new SqlCommand("select count(*) from tbl_custInfo where accountNumber = @accountNum", Program.GetSQLCon());
                cmd.Parameters.AddWithValue("@accountNum", newlyGeneratedAccountNum);
                var count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 0)  //account # doesn't already exist
                {
                    break;
                }
                newlyGeneratedAccountNum = string.Empty;
            }
            Program.GetSQLCon().Close();
            return newlyGeneratedAccountNum;
        }
        /*
         * Updates only the customer information that has changed
         */
        public static void UpdateCustomerData(Customer cust, CustomerProperty property)
        {
            var cmd = new SqlCommand();
            switch (property)
            {
                case CustomerProperty.BALANCE:
                    cmd = new SqlCommand("update tbl_custInfo set balance = @balance where accountNumber = @accountNum;", Program.GetSQLCon());
                    cmd.Parameters.AddWithValue("@balance", cust.custBalance);
                    cmd.Parameters.AddWithValue("@accountNum", cust.custAccountNumber);
                    break;
                case CustomerProperty.PWORD:
                    cmd = new SqlCommand("update tbl_login set pword = @pword where username = @username;", Program.GetSQLCon());
                    cmd.Parameters.AddWithValue("@pword", cust.custPassword);
                    cmd.Parameters.AddWithValue("@username", cust.custUsername);
                    break;
                case CustomerProperty.STATUS:
                    cmd = new SqlCommand("update tbl_login set accountStatus = @status where username = @username;", Program.GetSQLCon());
                    cmd.Parameters.AddWithValue("@status", cust.custAccountStatus);
                    cmd.Parameters.AddWithValue("@username", cust.custUsername);
                    break;
                case CustomerProperty.ATTEMPTS:
                    cmd = new SqlCommand("update tbl_login set attempts = @attempts where username = @username;", Program.GetSQLCon());
                    cmd.Parameters.AddWithValue("@attempts", cust.custLoginAttempts);
                    cmd.Parameters.AddWithValue("@username", cust.custUsername);
                    break;
            }
            cmd.ExecuteNonQuery();
        }
        /*
         * Adds a new customer to the tbl_login and tbl_custInfo databases
         */
        public static void AddCustomer(Customer cust)
        {
            var cmd = new SqlCommand("insert into tbl_login (username) values (@username)", Program.GetSQLCon());
            cmd.Parameters.AddWithValue("@username", cust.custUsername);

            Program.GetSQLCon().Open();

            cmd.ExecuteNonQuery();

            cmd = new SqlCommand("insert into tbl_custInfo (username, balance, accountNumber) values (@username, @balance, @accountNum)", Program.GetSQLCon());
            cmd.Parameters.AddWithValue("@username", cust.custUsername);
            cmd.Parameters.AddWithValue("@balance", cust.custBalance);
            cmd.Parameters.AddWithValue("@accountNum", cust.custAccountNumber);
            cmd.ExecuteNonQuery();

            Program.GetSQLCon().Close();
        }
        /*
         * Returns a Customer object based on an account #
         */
        public static Customer GetCustomer(string accountNumber)
        {
            var cust = new Customer();

            cust.custAccountNumber = accountNumber;

            var cmd = Program.GetSQLCon().CreateCommand();
                
            cmd.CommandText = "select username,balance from tbl_custInfo where accountNumber = @accountNum";
            cmd.Parameters.AddWithValue("@accountNum", accountNumber);
            var reader = cmd.ExecuteReader();
            reader.Read();
            cust.custUsername = Convert.ToString(reader["username"]);
            cust.custBalance = Convert.ToInt32(reader["balance"]);
            reader.Close();

            cmd = new SqlCommand("select pword,accountStatus,attempts from tbl_login where username = @username", Program.GetSQLCon());
            cmd.Parameters.AddWithValue("@username", cust.custUsername);
            
            reader = cmd.ExecuteReader();
            reader.Read();
            cust.custPassword = Convert.ToString(reader["pword"]);
            cust.custAccountStatus = Convert.ToBoolean(reader["accountStatus"]);
            cust.custLoginAttempts = Convert.ToInt32(reader["attempts"]);
            reader.Close();

            return cust;
        }
    }
}