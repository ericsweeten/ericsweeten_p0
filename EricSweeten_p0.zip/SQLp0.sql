use bankingDB

drop table tbl_transactions
drop table tbl_custInfo
drop table tbl_login

create table tbl_login
(
	username varchar(20) unique,
	pword varchar(20) default 'password',
	accountStatus bit default 1,
	attempts int default 0,

	constraint pk_username primary key(username)
--	constraint chk_pword_len check(len(pword) > 6)
)

insert into tbl_login(userName,pword) values('admin','password@123')
insert into tbl_login(userName,pword) values('Eric','password@123')
insert into tbl_login(userName,pword) values('Glen','password@123')
insert into tbl_login(userName,pword) values('Mike','password@123')

create table tbl_custInfo
(
	username varchar(20) unique,
	balance int default 0,
	accountNumber varchar(10) unique,

	constraint pk_accountNumber primary key(accountNumber),
	constraint fk_username foreign key(username) references tbl_login
)

insert into tbl_custInfo(username,balance,accountNumber) values('Eric',2500,'5431298209')
insert into tbl_custInfo(username,balance,accountNumber) values('Glen',1000,'8293921094')
insert into tbl_custInfo(username,balance,accountNumber) values('Mike',500,'7328923192')

create table tbl_transactions
(
	tranNo int identity (1,1),
	accountNumber varchar(10),
	dateAndTime varchar(20),
	amount int,
	by_ varchar(20),
	notes varchar(30)

	constraint pk_tranNo primary key(tranNo),
	constraint fk_accountNumber foreign key(accountNumber) references tbl_custInfo,
	constraint chk_by_ check (by_ in ('banker','customer','a fellow customer'))
)
