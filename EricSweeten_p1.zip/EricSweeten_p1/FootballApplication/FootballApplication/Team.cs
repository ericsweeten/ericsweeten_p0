﻿using System.Data.SqlClient;

namespace FootballApplication
{
    public class Team
    {
        private static string con = "server=DESKTOP-EMQBT1J\\ERIC_INSTANCE;database=footballDB;integrated security=true;";
        public int teamId { get; set; }
        public string teamName { get; set; }
        public string teamCountry { get; set; }
        public List<Team> GetAllTeams()
        {
            var con = new SqlConnection(GetSQLCon());
            var cmd = new SqlCommand("select * from tbl_footballTeams", con);
            con.Open();
            var teams = new List<Team>();
            var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                teams.Add(new Team()
                {
                    teamId = Convert.ToInt32(rd[0]),
                    teamName = Convert.ToString(rd[1]),
                    teamCountry = Convert.ToString(rd[2])
                });
            }
            rd.Close();
            con.Close();
            return teams;
        }
        public List<Player> GetTeamByName(string p_teamName)
        {
            var con = new SqlConnection(GetSQLCon());
            var cmd = new SqlCommand("select teamId from tbl_footballTeams where teamName=@teamName", con);
            cmd.Parameters.AddWithValue("@teamName", p_teamName);
            con.Open();
            var rd = cmd.ExecuteReader();
            rd.Read();
            cmd = new SqlCommand("select * from tbl_footballPlayers where teamId=@teamId", con);
            cmd.Parameters.AddWithValue("@teamId", rd[0].ToString());
            rd.Close();
            var players = new List<Player>();
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                players.Add(new Player()
                {
                    playerId = Convert.ToInt32(rd[0]),
                    playerName = Convert.ToString(rd[1]),
                    playerPosition = Convert.ToString(rd[2]),
                    playerTeamId = Convert.ToInt32(rd[3])
                });
            }
            rd.Close();
            con.Close();
            return players;
        }
        public bool AddNewTeam(Team p_team)
        {
            var con = new SqlConnection(GetSQLCon());
            var success = true;
            var cmd = new SqlCommand("insert into tbl_footballTeams values(@teamName,@teamCountry)", con);
            cmd.Parameters.AddWithValue("@teamName", p_team.teamName);
            cmd.Parameters.AddWithValue("@teamCountry", p_team.teamCountry);
            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                success = false;
            }
            con.Close();
            if (!success) throw new Exception("Invalid Team Name");
            return true;
        }
        public static string GetSQLCon()
        {
            return con;
        }
    }
}
