﻿using System.Data.SqlClient;

namespace FootballApplication
{
    public class Player
    {
        public int playerId { get; set; }
        public string playerName { get; set; }
        public string playerPosition { get; set; }
        public int playerTeamId { get; set; }
        public Player GetPlayerByName(string p_playerName)
        {
            var con = new SqlConnection(Team.GetSQLCon());
            var success = true;
            var cmd = new SqlCommand("select * from tbl_footballPlayers where playerName=@playerName", con);
            cmd.Parameters.AddWithValue("@playerName", p_playerName);
            con.Open();
            var player = new Player();
            var rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                player.playerId = Convert.ToInt32(rd[0]);
                player.playerName = Convert.ToString(rd[1]);
                player.playerPosition = Convert.ToString(rd[2]);
                player.playerTeamId = Convert.ToInt32(rd[3]);
            }
            else
            {
                success = false;
            }
            rd.Close();
            con.Close();
            if (!success) throw new Exception("Player not found");
            return player;
        }
        public List<Player> GetAllPlayersByPosition(string p_playerPosition)
        {
            var con = new SqlConnection(Team.GetSQLCon());
            var cmd = new SqlCommand("select * from tbl_footballPlayers where playerPosition=@playerPosition", con);
            cmd.Parameters.AddWithValue("@playerPosition", p_playerPosition);
            con.Open();
            var players = new List<Player>();
            var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                players.Add(new Player()
                {
                    playerId = Convert.ToInt32(rd[0]),
                    playerName = Convert.ToString(rd[1]),
                    playerPosition = Convert.ToString(rd[2]),
                    playerTeamId = Convert.ToInt32(rd[3])
                });
            }
            rd.Close();
            con.Close();
            return players;
        }
        public bool AddNewPlayer(Player p_player)
        {
            var con = new SqlConnection(Team.GetSQLCon());
            var success = true;
            var cmd = new SqlCommand("insert into tbl_footballPlayers values(@playerName,@playerPosition,@playerTeamId)", con);
            cmd.Parameters.AddWithValue("@playerName", p_player.playerName);
            cmd.Parameters.AddWithValue("@playerPosition", p_player.playerPosition);
            cmd.Parameters.AddWithValue("@playerTeamId", p_player.playerTeamId);
            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                success = false;
            }
            con.Close();
            if (!success) throw new Exception("Invalid data");
            return true;
        }
        //changes player team
        public bool UpdatePlayer(string p_playerName, int p_newTeam)
        {
            var con = new SqlConnection(Team.GetSQLCon());
            var success = true;
            var cmd = new SqlCommand("update tbl_footballPlayers set teamId=@playerTeamId where playerName=@playerName", con);
            cmd.Parameters.AddWithValue("@playerTeamId", p_newTeam);
            cmd.Parameters.AddWithValue("@playerName", p_playerName);
            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception exc)
            {
                success = false;
            }
            con.Close();
            if (!success) throw new Exception("Invalid data");
            return true;
        }
        public bool DeletePlayer(string p_playerName)
        {
            var con = new SqlConnection(Team.GetSQLCon());
            var success = true;
            var cmd = new SqlCommand("delete from tbl_footballPlayers where playerName=@playerName", con);
            cmd.Parameters.AddWithValue("@playerName", p_playerName);
            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception exc)
            {
                success = false;
            }
            con.Close();
            if (!success) throw new Exception("Player not found");
            return true;
        }
    }
}
