﻿using Microsoft.AspNetCore.Mvc;

namespace FootballApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamController : ControllerBase
    {
        [HttpGet]
        [Route("teamlist")]
        public IActionResult GetAllTeams()
        {
            var teamObj = new Team();
            return Ok(teamObj.GetAllTeams());
        }
        [HttpGet]
        [Route("teamlist/{p_teamName}")]
        public IActionResult GetTeamByName(string p_teamName)
        {
            var teamObj = new Team();
            try
            {
                return Ok(teamObj.GetTeamByName(p_teamName));
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }
        [HttpPut]
        [Route("teamlist/addteam/{p_teamName}/{p_teamCountry}")]
        public IActionResult AddTeam(string p_teamName, string p_teamCountry)
        {
            var teamObj = new Team();
            var team = new Team()
            {
                teamName = p_teamName,
                teamCountry = p_teamCountry
            };
            try
            {
                return Ok(teamObj.AddNewTeam(team));
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
