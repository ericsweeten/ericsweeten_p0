﻿using Microsoft.AspNetCore.Mvc;

namespace FootballApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayerController : ControllerBase
    {
        [HttpGet]
        [Route("playerlist/{p_playerName}")]
        public IActionResult GetPlayerByName(string p_playerName)
        {
            var playerObj = new Player();
            try
            {
                return Ok(playerObj.GetPlayerByName(p_playerName));
            }
            catch
            {
                return BadRequest();
            }
        }
        [HttpGet]
        [Route("playerlist/position/{p_playerPosition}")]
        public IActionResult GetAllPlayersByPosition(string p_playerPosition)
        {
            var playerObj = new Player();
            try
            {
                return Ok(playerObj.GetAllPlayersByPosition(p_playerPosition));
            }
            catch
            {
                return BadRequest();
            }
        }
        [HttpPut]
        [Route("playerlist/add/{p_playerName}/{p_playerPosition}/{p_playerTeamId}")]
        public IActionResult AddPlayer(string p_playerName, string p_playerPosition, int p_playerTeamId)
        {
            var playerObj = new Player();
            var player = new Player()
            {
                playerName = p_playerName,
                playerPosition = p_playerPosition,
                playerTeamId = p_playerTeamId
            };
            try
            {
                return Ok(playerObj.AddNewPlayer(player));
            }
            catch
            {
                return BadRequest();
            }
        }
        [HttpPut]
        [Route("playerlist/update/{p_playerName}/{p_playerTeamId}")]
        public IActionResult UpdatePlayer(string p_playerName, int p_playerTeamId)  //changes player's team
        {
            var playerObj = new Player();
            try
            {
                return Ok(playerObj.UpdatePlayer(p_playerName, p_playerTeamId));
            }
            catch
            {
                return BadRequest();
            }
        }
        [HttpDelete]
        [Route("playerlist/delete/{p_playerName}")]
        public IActionResult DeletePlayer(string p_playerName)
        {
            var playerObj = new Player();
            try
            {
                return Ok(playerObj.DeletePlayer(p_playerName));
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
